from collections import defaultdict
from typing import Iterable

from ..config import AppConfig
from ..execution.paper_broker import PaperBroker
from ..models import Bar
from ..risk.risk_manager import RiskManager
from ..strategies.strategy_engine import StrategyEngine
from ..utils.logger import EventLogger


class Backtester:
    """
    Runs the bot candle-by-candle.

    Job:
    1. Feed candles into strategy engine.
    2. Check if open trades hit stop/target.
    3. Ask strategy for a new signal.
    4. Ask risk manager if the signal is allowed.
    5. Place paper trade if allowed.
    6. Summarize results.
    """

    def __init__(self, cfg: AppConfig, bars: Iterable[Bar]):
        self.cfg = cfg
        self.bars = list(bars)

        self.events = EventLogger(cfg.event_log_file)
        self.risk = RiskManager(cfg)
        self.broker = PaperBroker(cfg)
        self.strategy = StrategyEngine(cfg)

    def run(self) -> dict:
        for bar in self.bars:
            self._on_bar(bar)

        return self.summary()

    def _on_bar(self, bar: Bar) -> None:
        current_day = bar.timestamp.date()
        old_day = self.risk.state.day

        self.risk.reset_new_day(current_day)

        if current_day != old_day:
            self.events.log(f"New session: {current_day}")

        self.strategy.on_bar(bar)

        closed_order = self.broker.on_bar(bar)

        if closed_order is not None:
            self.risk.register_closed_trade(closed_order)

            if closed_order.exit_reason is not None:
                self.events.log(
                    f"Closed {closed_order.order_id}: "
                    f"{closed_order.exit_reason.value} "
                    f"PnL=${closed_order.pnl:.2f}"
                )
            else:
                self.events.log(
                    f"Closed {closed_order.order_id}: "
                    f"PnL=${closed_order.pnl:.2f}"
                )

        signal = self.strategy.get_signal(bar)

        if signal is None:
            return

        decision = self.risk.can_enter(self.broker.open_order)

        if decision.allowed:
            stop_price, target_price = self.risk.build_bracket_prices(
                signal.side,
                signal.entry_reference_price,
            )

            order = self.broker.place_bracket_order(
                signal=signal,
                qty=self.cfg.risk.max_contracts,
                entry_price=signal.entry_reference_price,
                stop_price=stop_price,
                target_price=target_price,
                opened_at=bar.timestamp,
            )

            self.events.log(
                f"OPEN {order.order_id} {order.side.value} {order.qty}x "
                f"entry={order.entry_price:.2f} stop={order.stop_price:.2f} "
                f"target={order.target_price:.2f} strategy={order.strategy_name} | "
                f"{signal.reason}"
            )
        else:
            reason = decision.reason

            if getattr(self.cfg.report, "print_rejected_signals", True):
                self.events.log(f"Signal rejected: {reason}")

    def summary(self) -> dict:
        closed = self.broker.closed_orders

        total_pnl = sum(o.pnl for o in closed)
        wins = [o for o in closed if o.pnl > 0]
        losses = [o for o in closed if o.pnl < 0]

        by_strategy = defaultdict(float)

        for order in closed:
            by_strategy[order.strategy_name] += order.pnl

        trade_count = len(closed)
        win_count = len(wins)
        loss_count = len(losses)

        win_rate = 0.0
        avg_pnl = 0.0

        if trade_count > 0:
            win_rate = round((win_count / trade_count) * 100, 2)
            avg_pnl = round(total_pnl / trade_count, 2)

        return {
            "trades": trade_count,
            "wins": win_count,
            "losses": loss_count,
            "win_rate": win_rate,
            "total_pnl": round(total_pnl, 2),
            "avg_pnl": avg_pnl,
            "by_strategy": dict(by_strategy),
        }