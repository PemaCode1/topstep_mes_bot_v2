from datetime import datetime
from typing import Optional

from ..config import AppConfig
from ..models import Bar, BracketOrder, ExitReason, OrderStatus, Side, Signal
from ..utils.session import parse_hhmm, to_session_time


class PaperBroker:
    """
    Simulated broker for backtesting/paper testing.

    Job:
    1. Place fake bracket orders.
    2. Track one open position.
    3. Close trades at stop loss, take profit, or session flatten.
    4. Calculate P/L with estimated commission.
    """

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.open_order: Optional[BracketOrder] = None
        self.closed_orders: list[BracketOrder] = []
        self.order_counter: int = 0

    def place_bracket_order(
        self,
        signal: Signal,
        qty: int,
        entry_price: float,
        stop_price: float,
        target_price: float,
        opened_at: datetime,
    ) -> BracketOrder:
        """
        Open one simulated bracket order.

        The signal gives:
        - LONG or SHORT
        - strategy name
        - entry reason
        """

        if self.open_order is not None:
            raise RuntimeError("Cannot open a new order while another order is already open.")

        self.order_counter += 1
        order_id = f"PAPER-{self.order_counter:06d}"

        order = BracketOrder(
            order_id=order_id,
            side=signal.side,
            qty=qty,
            entry_price=entry_price,
            stop_price=stop_price,
            target_price=target_price,
            opened_at=opened_at,
            strategy_name=signal.strategy_name,
            status=OrderStatus.OPEN,
        )

        self.open_order = order
        return order

    def on_bar(self, bar: Bar) -> Optional[BracketOrder]:
        """
        Check the open order against the newest candle.

        Returns a closed order if stop, target, or session flatten happened.
        Returns None if no trade closed.
        """

        if self.open_order is None:
            return None

        order = self.open_order

        current_time = to_session_time(bar.timestamp, self.cfg.session.timezone)
        flatten_time = parse_hhmm(self.cfg.session.flatten_by)

        if current_time >= flatten_time:
            return self._close(
                order=order,
                closed_at=bar.timestamp,
                exit_price=bar.close,
                reason=ExitReason.SESSION_FLATTEN,
            )

        if order.side == Side.LONG:
            if bar.low <= order.stop_price:
                return self._close(
                    order=order,
                    closed_at=bar.timestamp,
                    exit_price=order.stop_price,
                    reason=ExitReason.STOP_LOSS,
                )

            if bar.high >= order.target_price:
                return self._close(
                    order=order,
                    closed_at=bar.timestamp,
                    exit_price=order.target_price,
                    reason=ExitReason.TAKE_PROFIT,
                )

        if order.side == Side.SHORT:
            if bar.high >= order.stop_price:
                return self._close(
                    order=order,
                    closed_at=bar.timestamp,
                    exit_price=order.stop_price,
                    reason=ExitReason.STOP_LOSS,
                )

            if bar.low <= order.target_price:
                return self._close(
                    order=order,
                    closed_at=bar.timestamp,
                    exit_price=order.target_price,
                    reason=ExitReason.TAKE_PROFIT,
                )

        return None

    def _close(
        self,
        order: BracketOrder,
        closed_at: datetime,
        exit_price: float,
        reason: ExitReason,
    ) -> BracketOrder:
        """
        Close the open paper order.
        """

        order.status = OrderStatus.CLOSED
        order.closed_at = closed_at
        order.exit_price = exit_price
        order.exit_reason = reason
        order.pnl = self._calculate_pnl(order)

        self.closed_orders.append(order)
        self.open_order = None

        return order

    def _calculate_pnl(self, order: BracketOrder) -> float:
        """
        Calculate MES P/L.

        MES:
        - 1 point = $5.00
        - 1 tick = 0.25 points
        - 1 tick = $1.25

        Formula:
        points gained/lost × point value × contracts - commission
        """

        points = order.exit_price - order.entry_price

        if order.side == Side.SHORT:
            points *= -1

        gross_pnl = points * self.cfg.instrument.point_value * order.qty
        commission = getattr(self.cfg.risk, "commission_per_round_trip", 0.0)

        return round(gross_pnl - commission, 2)