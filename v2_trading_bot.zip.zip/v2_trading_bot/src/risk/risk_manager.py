from dataclasses import dataclass
from datetime import date
from typing import Optional
from ..config import AppConfig
from ..models import BracketOrder, TradeDecision, Side
from ..indicators import round_to_tick


@dataclass
class DailyRiskState:
    day: date
    realized_pnl: float = 0.0
    trades_taken: int = 0
    consecutive_losses: int = 0
    locked: bool = False
    lock_reason: str = ""


class RiskManager:
    """Prop-firm style risk guardrails.

    This class is intentionally strict. The purpose is not to maximize entries.
    The purpose is to prevent one bad bot day from destroying an evaluation.
    """

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.state = DailyRiskState(day=date.today())

    def reset_new_day(self, current_day: date) -> None:
        if current_day != self.state.day:
            self.state = DailyRiskState(day=current_day)

    def lock(self, reason: str) -> None:
        self.state.locked = True
        self.state.lock_reason = reason

    def can_enter(self, open_order: Optional[BracketOrder]) -> TradeDecision:
        if self.state.locked:
            return TradeDecision(False, f"BOT LOCKED: {self.state.lock_reason}")
        if open_order is not None:
            return TradeDecision(False, "Open position exists. One trade at a time only.")
        if self.state.realized_pnl <= -abs(self.cfg.risk.max_daily_loss_dollars):
            self.lock("Daily bot loss limit hit.")
            return TradeDecision(False, "Daily bot loss limit hit.")
        if self.state.trades_taken >= self.cfg.risk.max_trades_per_day:
            return TradeDecision(False, "Max trades per day reached.")
        if self.state.consecutive_losses >= self.cfg.risk.max_consecutive_losses:
            self.lock("Max consecutive losses hit.")
            return TradeDecision(False, "Max consecutive losses hit.")
        return TradeDecision(True, "OK")

    def build_bracket_prices(self, side: Side, entry_price: float) -> tuple[float, float]:
        tick = self.cfg.instrument.tick_size
        sl_offset = self.cfg.risk.stop_loss_ticks * tick
        tp_offset = self.cfg.risk.take_profit_ticks * tick

        if side == Side.LONG:
            stop = entry_price - sl_offset
            target = entry_price + tp_offset
        else:
            stop = entry_price + sl_offset
            target = entry_price - tp_offset

        return round_to_tick(stop, tick), round_to_tick(target, tick)

    def register_closed_trade(self, order: BracketOrder) -> None:
        self.state.realized_pnl += order.pnl
        self.state.trades_taken += 1
        if order.pnl < 0:
            self.state.consecutive_losses += 1
        else:
            self.state.consecutive_losses = 0

        if self.state.realized_pnl <= -abs(self.cfg.risk.max_daily_loss_dollars):
            self.lock("Daily bot loss limit hit after trade close.")
        if self.state.consecutive_losses >= self.cfg.risk.max_consecutive_losses:
            self.lock("Consecutive loss limit hit after trade close.")
